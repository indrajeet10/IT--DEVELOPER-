import { useState, useEffect } from "react";
import SummaryCards from "../components/SummaryCards.jsx";
import GoalCard from "../components/GoalCard.jsx";
import TransactionForm from "../components/TransactionForm.jsx";
import TransactionsTable from "../components/TransactionsTable.jsx";
import ChartsPanel from "../components/ChartsPanel.jsx";
import { useAuth } from "../context/AuthContext.jsx";

const Dashboard = () => {
  const { user } = useAuth();

  const [transactions, setTransactions] = useState(
    JSON.parse(localStorage.getItem("pfms_transactions")) || []
  );

  const [editingTx, setEditingTx] = useState(null);

  const [goalAmount, setGoalAmount] = useState(
    Number(localStorage.getItem("pfms_goal")) || 20000
  );

  useEffect(() => {
    localStorage.setItem("pfms_transactions", JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem("pfms_goal", goalAmount);
  }, [goalAmount]);

  const handleSave = (tx) => {
    if (editingTx) {
      setTransactions((prev) => prev.map((p) => (p.id === tx.id ? tx : p)));
      setEditingTx(null);
    } else {
      setTransactions((prev) => [tx, ...prev]);
    }
  };

  const handleDelete = (id) => {
    setTransactions((prev) => prev.filter((t) => t.id !== id));
  };

  const totalIncome = transactions
    .filter((t) => t.type === "income")
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenses = transactions
    .filter((t) => t.type === "expense")
    .reduce((sum, t) => sum + t.amount, 0);

  const netSavings = totalIncome - totalExpenses;

  const categoryTotals = {};
  transactions
    .filter((t) => t.type === "expense")
    .forEach((t) => {
      categoryTotals[t.category] = (categoryTotals[t.category] || 0) + t.amount;
    });

  const biggestCategory =
    Object.keys(categoryTotals).length > 0
      ? Object.entries(categoryTotals).sort((a, b) => b[1] - a[1])[0][0]
      : null;

  return (
    <div className="container">
      <h2>Welcome, {user?.name}</h2>
      <p>Your financial dashboard</p>

      <SummaryCards
        totalIncome={totalIncome}
        totalExpenses={totalExpenses}
        netSavings={netSavings}
        biggestCategory={biggestCategory}
      />

      <GoalCard
        goalAmount={goalAmount}
        netSavings={netSavings}
        onGoalChange={setGoalAmount}
      />

      <TransactionForm
        onSubmit={handleSave}
        editing={!!editingTx}
        initialData={editingTx}
        onCancel={() => setEditingTx(null)}
      />

      <ChartsPanel transactions={transactions} />

      <TransactionsTable
        transactions={transactions}
        onEdit={(tx) => setEditingTx(tx)}
        onDelete={handleDelete}
      />
    </div>
  );
};

export default Dashboard;
