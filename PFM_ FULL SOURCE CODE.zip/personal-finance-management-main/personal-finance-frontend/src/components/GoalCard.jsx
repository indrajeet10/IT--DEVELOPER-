const GoalCard = ({ goalAmount, netSavings, onGoalChange }) => {
  const progress = Math.min((netSavings / goalAmount) * 100, 100);

  return (
    <div className="card mt-3">
      <h3>Monthly Savings Goal</h3>

      <label>Goal Amount (₹)</label>
      <input
        type="number"
        className="input mt-1"
        value={goalAmount}
        onChange={(e) => onGoalChange(Number(e.target.value))}
      />

      <p className="mt-2">Progress: {progress.toFixed(1)}%</p>

      <div style={{
        height: "10px",
        background: "#ddd",
        borderRadius: "8px",
        overflow: "hidden"
      }}>
        <div style={{
          width: `${progress}%`,
          height: "100%",
          background: "green"
        }} />
      </div>
    </div>
  );
};

export default GoalCard;
