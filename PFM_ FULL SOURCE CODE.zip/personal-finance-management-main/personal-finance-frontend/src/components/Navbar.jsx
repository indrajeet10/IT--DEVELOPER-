import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

function Navbar() {
  const { user, logout } = useAuth();

  return (
    <nav className="navbar">
      <div className="nav-container">

        {/* LEFT LOGO */}
        <Link to="/dashboard" className="nav-logo">
          <img src="/rr-logo.png" alt="logo" className="logo-img" />

          {/* FINAL SINGLE TEXT */}
          <span className="nav-logo-text">PERSONAL FINANCE</span>
        </Link>

        {/* RIGHT SIDE */}
        <div className="nav-right">
          {user && <span className="nav-user">Hi, {user.name}</span>}
          {user && (
            <button className="nav-logout-btn" onClick={logout}>
              Logout
            </button>
          )}
        </div>

      </div>
    </nav>
  );
}

export default Navbar;
