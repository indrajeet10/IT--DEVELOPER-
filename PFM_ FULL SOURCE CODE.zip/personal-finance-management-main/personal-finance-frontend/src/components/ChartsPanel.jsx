import { Pie, Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
} from "chart.js";

ChartJS.register(ArcElement, Tooltip, Legend, CategoryScale, LinearScale, BarElement);

const ChartsPanel = ({ transactions }) => {
  const income = transactions.filter((t) => t.type === "income");
  const expenses = transactions.filter((t) => t.type === "expense");

  const categories = [...new Set(expenses.map((e) => e.category || "Other"))];
  const categoryTotals = categories.map(
    (c) => expenses.filter((e) => e.category === c).reduce((s, e) => s + e.amount, 0)
  );

  return (
    <div className="grid grid-3 mt-3">
      <div className="card">
        <h3>Expense by Category</h3>
        {expenses.length === 0 ? (
          <p>No expenses yet.</p>
        ) : (
          <Pie
            data={{
              labels: categories,
              datasets: [{ data: categoryTotals }],
            }}
          />
        )}
      </div>

      <div className="card">
        <h3>Income vs Expenses</h3>
        <Bar
          data={{
            labels: ["Income", "Expenses"],
            datasets: [
              {
                data: [
                  income.reduce((s, i) => s + i.amount, 0),
                  expenses.reduce((s, e) => s + e.amount, 0),
                ],
              },
            ],
          }}
        />
      </div>
    </div>
  );
};

export default ChartsPanel;
