const TransactionsTable = ({ transactions, onEdit, onDelete }) => {
  return (
    <div className="card mt-3">
      <h3>All Transactions</h3>

      {transactions.length === 0 ? (
        <p>No transactions yet.</p>
      ) : (
        <table className="table">
          <thead>
            <tr>
              <th>Type</th>
              <th>Amount</th>
              <th>Category/Source</th>
              <th>Payment</th>
              <th>Date</th>
              <th />
            </tr>
          </thead>

          <tbody>
            {transactions.map((tx) => (
              <tr key={tx.id}>
                <td>{tx.type}</td>
                <td>₹{tx.amount}</td>
                <td>{tx.type === "income" ? tx.source : tx.category}</td>
                <td>{tx.paymentMethod || "-"}</td>
                <td>{tx.date}</td>
                <td>
                  <button className="btn btn-outline" onClick={() => onEdit(tx)}>Edit</button>
                  <button className="btn btn-danger" onClick={() => onDelete(tx.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default TransactionsTable;
