const SummaryCards = ({ totalIncome, totalExpenses, netSavings, biggestCategory }) => {
  return (
    <div className="grid grid-3 mt-3">
      <div className="card">
        <h3>Total Income</h3>
        <p>₹{totalIncome.toFixed(2)}</p>
      </div>

      <div className="card">
        <h3>Total Expenses</h3>
        <p>₹{totalExpenses.toFixed(2)}</p>
      </div>

      <div className="card">
        <h3>Net Savings</h3>
        <p style={{ color: netSavings >= 0 ? "green" : "red" }}>
          ₹{netSavings.toFixed(2)}
        </p>

        {biggestCategory && (
          <p className="text-sm text-muted">
            Biggest Expense: {biggestCategory}
          </p>
        )}
      </div>
    </div>
  );
};

export default SummaryCards;
