import { useState, useEffect } from "react";

const TransactionForm = ({ onSubmit, editing, initialData, onCancel }) => {
  const [form, setForm] = useState({
    type: "expense",
    amount: "",
    date: "",
    category: "Food",
    payment: "Cash",
    notes: "",
  });

  useEffect(() => {
    if (editing) setForm(initialData);
  }, [editing, initialData]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.amount || !form.date) return;

    if (editing) onSubmit(form);
    else onSubmit({ ...form, id: Date.now() });

    setForm({
      type: "expense",
      amount: "",
      date: "",
      category: "Food",
      payment: "Cash",
      notes: "",
    });
  };

  return (
    <div className="card transaction-form">
      <h3>{editing ? "Edit Transaction" : "Add Transaction"}</h3>

      <form onSubmit={handleSubmit}>
        <div className="transaction-grid">

          <div>
            <label>Type</label>
            <select name="type" className="input" value={form.type} onChange={handleChange}>
              <option value="expense">Expense</option>
              <option value="income">Income</option>
            </select>
          </div>

          <div>
            <label>Amount</label>
            <input
              type="number"
              name="amount"
              className="input"
              value={form.amount}
              onChange={handleChange}
            />
          </div>

          <div>
            <label>Date</label>
            <input
              type="date"
              name="date"
              className="input"
              value={form.date}
              onChange={handleChange}
            />
          </div>

          <div>
            <label>Category</label>
            <select name="category" className="input" value={form.category} onChange={handleChange}>
              <option>Food</option>
              <option>Travel</option>
              <option>Shopping</option>
              <option>Health</option>
              <option>Salary</option>
              <option>Other</option>
            </select>
          </div>

          <div>
            <label>Payment Method</label>
            <select name="payment" className="input" value={form.payment} onChange={handleChange}>
              <option>Cash</option>
              <option>UPI</option>
              <option>Bank Transfer</option>
              <option>Card</option>
            </select>
          </div>

          <div>
            <label>Notes</label>
            <textarea
              name="notes"
              className="input"
              value={form.notes}
              onChange={handleChange}
            ></textarea>
          </div>
        </div>

        <button className="btn btn-primary">{editing ? "Save" : "Add"}</button>

        {editing && (
          <button type="button" className="btn btn-outline" onClick={onCancel} style={{ marginLeft: "1rem" }}>
            Cancel
          </button>
        )}
      </form>
    </div>
  );
};

export default TransactionForm;
