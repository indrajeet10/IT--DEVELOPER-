import { createContext, useContext, useState } from "react";

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(
    JSON.parse(localStorage.getItem("pfms_user")) || null
  );

  const login = async ({ email, password }) => {
    const fakeUser = { name: "User", email };
    const fakeToken = "token123";

    localStorage.setItem("pfms_user", JSON.stringify(fakeUser));
    localStorage.setItem("pfms_token", fakeToken);

    setUser(fakeUser);
    return true;
  };

  const register = async ({ name, email, password }) => {
    const fakeUser = { name, email };
    const fakeToken = "token123";

    localStorage.setItem("pfms_user", JSON.stringify(fakeUser));
    localStorage.setItem("pfms_token", fakeToken);

    setUser(fakeUser);
    return true;
  };

  const logout = () => {
    localStorage.removeItem("pfms_user");
    localStorage.removeItem("pfms_token");
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
