import React, { useState } from "react";
import { useListRecurringTransactions, useCreateRecurringTransaction, useUpdateRecurringTransaction, useDeleteRecurringTransaction, useApplyRecurringTransactions, useListCategories } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { RefreshCw, Plus, Pencil, Trash2, Play, AlertCircle } from "lucide-react";

type Frequency = "daily" | "weekly" | "monthly" | "yearly";
type TxType = "income" | "expense";

const FREQUENCIES: { value: Frequency; label: string }[] = [
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
  { value: "monthly", label: "Monthly" },
  { value: "yearly", label: "Yearly" },
];

const FREQ_LABELS: Record<Frequency, string> = {
  daily: "Daily",
  weekly: "Weekly",
  monthly: "Monthly",
  yearly: "Yearly",
};

interface FormState {
  type: TxType;
  amount: string;
  categoryId: string;
  source: string;
  paymentMethod: string;
  notes: string;
  frequency: Frequency;
  startDate: string;
  endDate: string;
  isActive: boolean;
}

const defaultForm = (): FormState => ({
  type: "expense",
  amount: "",
  categoryId: "",
  source: "",
  paymentMethod: "",
  notes: "",
  frequency: "monthly",
  startDate: new Date().toISOString().slice(0, 10),
  endDate: "",
  isActive: true,
});

export default function RecurringTransactions() {
  const { toast } = useToast();
  const { data, isLoading, refetch } = useListRecurringTransactions();
  const { data: catData } = useListCategories();
  const createMutation = useCreateRecurringTransaction();
  const updateMutation = useUpdateRecurringTransaction();
  const deleteMutation = useDeleteRecurringTransaction();
  const applyMutation = useApplyRecurringTransactions();

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [form, setForm] = useState<FormState>(defaultForm());
  const [deleteConfirm, setDeleteConfirm] = useState<number | null>(null);

  const categories = catData?.categories ?? [];
  const recurring = data?.recurringTransactions ?? [];

  const openCreate = () => {
    setEditingId(null);
    setForm(defaultForm());
    setShowModal(true);
  };

  const openEdit = (rt: (typeof recurring)[number]) => {
    setEditingId(rt.id);
    setForm({
      type: rt.type as TxType,
      amount: String(rt.amount),
      categoryId: rt.categoryId ? String(rt.categoryId) : "",
      source: rt.source ?? "",
      paymentMethod: rt.paymentMethod ?? "",
      notes: rt.notes ?? "",
      frequency: rt.frequency as Frequency,
      startDate: rt.startDate,
      endDate: rt.endDate ?? "",
      isActive: rt.isActive,
    });
    setShowModal(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const amount = parseFloat(form.amount);
    if (isNaN(amount) || amount <= 0) {
      toast({ title: "Invalid amount", variant: "destructive" });
      return;
    }

    const payload = {
      type: form.type,
      amount,
      categoryId: form.categoryId ? parseInt(form.categoryId) : undefined,
      source: form.source || undefined,
      paymentMethod: form.paymentMethod || undefined,
      notes: form.notes || undefined,
      frequency: form.frequency,
      startDate: form.startDate,
      endDate: form.endDate || undefined,
      isActive: form.isActive,
      nextDate: form.startDate,
    };

    try {
      if (editingId !== null) {
        await updateMutation.mutateAsync({ id: editingId, data: payload });
        toast({ title: "Recurring entry updated" });
      } else {
        await createMutation.mutateAsync({ data: payload });
        toast({ title: "Recurring entry created" });
      }
      setShowModal(false);
      refetch();
    } catch {
      toast({ title: "Something went wrong", variant: "destructive" });
    }
  };

  const handleDelete = async (id: number) => {
    try {
      await deleteMutation.mutateAsync({ id });
      toast({ title: "Recurring entry deleted" });
      setDeleteConfirm(null);
      refetch();
    } catch {
      toast({ title: "Failed to delete", variant: "destructive" });
    }
  };

  const handleApply = async () => {
    try {
      const result = await applyMutation.mutateAsync({});
      toast({ title: `Applied ${result.applied} recurring transaction${result.applied !== 1 ? "s" : ""}` });
      refetch();
    } catch {
      toast({ title: "Failed to apply recurring entries", variant: "destructive" });
    }
  };

  const filteredCategories = categories.filter((c) => c.type === form.type || c.type === "both");

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-semibold text-foreground">Recurring Entries</h1>
          <p className="text-sm text-muted-foreground mt-1">Automate repeating income and expenses</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleApply}
            disabled={applyMutation.isPending}
            className="flex items-center gap-2 px-4 py-2 rounded-md border border-border text-sm font-medium text-foreground hover:bg-secondary/50 transition-colors disabled:opacity-50"
          >
            <Play className="w-4 h-4" />
            {applyMutation.isPending ? "Applying…" : "Apply Due"}
          </button>
          <button
            onClick={openCreate}
            className="flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            <Plus className="w-4 h-4" />
            New Recurring Entry
          </button>
        </div>
      </div>

      {/* Info banner */}
      <div className="mb-6 flex items-start gap-3 bg-primary/5 border border-primary/20 rounded-lg p-4 text-sm text-foreground">
        <RefreshCw className="w-4 h-4 mt-0.5 text-primary flex-shrink-0" />
        <p>
          Recurring entries are templates. Click <strong>Apply Due</strong> to create actual transaction records for all entries whose next date is today or earlier.
        </p>
      </div>

      {isLoading ? (
        <div className="text-center py-20 text-muted-foreground">Loading…</div>
      ) : recurring.length === 0 ? (
        <div className="text-center py-20">
          <RefreshCw className="w-12 h-12 mx-auto mb-4 text-muted-foreground/40" />
          <p className="text-muted-foreground font-medium">No recurring entries yet</p>
          <p className="text-sm text-muted-foreground/70 mt-1">Add your salary, rent, subscriptions, and more</p>
          <button
            onClick={openCreate}
            className="mt-4 px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors"
          >
            Add Your First Entry
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {recurring.map((rt) => {
            const cat = categories.find((c) => c.id === rt.categoryId);
            const isIncome = rt.type === "income";
            return (
              <div
                key={rt.id}
                className={`bg-card border rounded-xl p-5 flex items-center gap-4 ${!rt.isActive ? "opacity-50" : ""}`}
              >
                <div
                  className="w-2 self-stretch rounded-full flex-shrink-0"
                  style={{ backgroundColor: cat?.color ?? (isIncome ? "#0f766e" : "#ef4444") }}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-medium text-foreground">
                      {rt.source || cat?.name || (isIncome ? "Income" : "Expense")}
                    </span>
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                        isIncome ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive"
                      }`}
                    >
                      {isIncome ? "Income" : "Expense"}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-secondary text-muted-foreground font-medium">
                      {FREQ_LABELS[rt.frequency as Frequency]}
                    </span>
                    {!rt.isActive && (
                      <span className="text-xs px-2 py-0.5 rounded-full bg-muted text-muted-foreground">Paused</span>
                    )}
                  </div>
                  <div className="mt-1 flex items-center gap-3 text-sm text-muted-foreground flex-wrap">
                    {cat && <span style={{ color: cat.color }}>{cat.name}</span>}
                    <span>Next: {rt.nextDate}</span>
                    {rt.endDate && <span>Ends: {rt.endDate}</span>}
                    {rt.notes && <span className="truncate max-w-[200px]">{rt.notes}</span>}
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className={`text-lg font-semibold ${isIncome ? "text-primary" : "text-destructive"}`}>
                    {isIncome ? "+" : "-"}${rt.amount.toFixed(2)}
                  </p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  <button
                    onClick={() => openEdit(rt)}
                    className="p-2 rounded-md text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setDeleteConfirm(rt.id)}
                    className="p-2 rounded-md text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Create / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="bg-background rounded-2xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <form onSubmit={handleSubmit}>
              <div className="p-6 border-b border-border">
                <h2 className="text-lg font-semibold">{editingId ? "Edit Recurring Entry" : "New Recurring Entry"}</h2>
              </div>
              <div className="p-6 space-y-4">
                {/* Type */}
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Type</label>
                  <div className="grid grid-cols-2 gap-2">
                    {(["income", "expense"] as TxType[]).map((t) => (
                      <button
                        key={t}
                        type="button"
                        onClick={() => setForm((f) => ({ ...f, type: t, categoryId: "" }))}
                        className={`py-2 rounded-md text-sm font-medium border transition-colors capitalize ${
                          form.type === t
                            ? t === "income"
                              ? "bg-primary text-primary-foreground border-primary"
                              : "bg-destructive text-white border-destructive"
                            : "bg-background text-muted-foreground border-border hover:bg-secondary/50"
                        }`}
                      >
                        {t}
                      </button>
                    ))}
                  </div>
                </div>
                {/* Amount */}
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Amount</label>
                  <input
                    type="number"
                    min="0.01"
                    step="0.01"
                    required
                    value={form.amount}
                    onChange={(e) => setForm((f) => ({ ...f, amount: e.target.value }))}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="0.00"
                  />
                </div>
                {/* Category */}
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Category</label>
                  <select
                    value={form.categoryId}
                    onChange={(e) => setForm((f) => ({ ...f, categoryId: e.target.value }))}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    <option value="">No category</option>
                    {filteredCategories.map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
                {/* Source */}
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Label / Source</label>
                  <input
                    type="text"
                    value={form.source}
                    onChange={(e) => setForm((f) => ({ ...f, source: e.target.value }))}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="e.g. Monthly Salary, Netflix, Rent…"
                  />
                </div>
                {/* Frequency */}
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Frequency</label>
                  <div className="grid grid-cols-4 gap-2">
                    {FREQUENCIES.map((f) => (
                      <button
                        key={f.value}
                        type="button"
                        onClick={() => setForm((prev) => ({ ...prev, frequency: f.value }))}
                        className={`py-2 rounded-md text-sm font-medium border transition-colors ${
                          form.frequency === f.value
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-background text-muted-foreground border-border hover:bg-secondary/50"
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                </div>
                {/* Dates */}
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Start Date</label>
                    <input
                      type="date"
                      required
                      value={form.startDate}
                      onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))}
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">End Date <span className="text-muted-foreground">(optional)</span></label>
                    <input
                      type="date"
                      value={form.endDate}
                      onChange={(e) => setForm((f) => ({ ...f, endDate: e.target.value }))}
                      className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    />
                  </div>
                </div>
                {/* Notes */}
                <div>
                  <label className="block text-sm font-medium text-foreground mb-1.5">Notes <span className="text-muted-foreground">(optional)</span></label>
                  <input
                    type="text"
                    value={form.notes}
                    onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                    className="w-full h-10 px-3 rounded-md border border-input bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
                    placeholder="Optional note"
                  />
                </div>
                {/* Active toggle */}
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, isActive: !f.isActive }))}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${form.isActive ? "bg-primary" : "bg-muted"}`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${form.isActive ? "translate-x-6" : "translate-x-1"}`}
                    />
                  </button>
                  <span className="text-sm font-medium text-foreground">{form.isActive ? "Active" : "Paused"}</span>
                </div>
              </div>
              <div className="p-6 border-t border-border flex gap-3 justify-end">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 rounded-md text-sm font-medium text-foreground border border-border hover:bg-secondary/50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={createMutation.isPending || updateMutation.isPending}
                  className="px-4 py-2 bg-primary text-primary-foreground rounded-md text-sm font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
                >
                  {editingId ? "Save Changes" : "Create Entry"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete confirm modal */}
      {deleteConfirm !== null && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="bg-background rounded-2xl shadow-xl w-full max-w-sm p-6">
            <div className="flex items-center gap-3 mb-4">
              <AlertCircle className="w-6 h-6 text-destructive flex-shrink-0" />
              <h2 className="text-lg font-semibold">Delete recurring entry?</h2>
            </div>
            <p className="text-sm text-muted-foreground mb-6">This will stop future applications of this entry. Past transactions created from it will remain.</p>
            <div className="flex gap-3 justify-end">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="px-4 py-2 rounded-md text-sm font-medium text-foreground border border-border hover:bg-secondary/50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                disabled={deleteMutation.isPending}
                className="px-4 py-2 bg-destructive text-white rounded-md text-sm font-medium hover:bg-destructive/90 transition-colors disabled:opacity-50"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
