import React, { useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileDown } from "lucide-react";
import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { useGetDashboardSummary, useGetCategoryBreakdown, useListTransactions } from "@workspace/api-client-react";
import { formatCurrency, formatDate } from "@/lib/format";
import { Skeleton } from "@/components/ui/skeleton";

export default function Reports() {
  const reportRef = useRef<HTMLDivElement>(null);
  
  const { data: summary, isLoading: isLoadingSummary } = useGetDashboardSummary();
  const { data: breakdown, isLoading: isLoadingBreakdown } = useGetCategoryBreakdown();
  const { data: txData, isLoading: isLoadingTx } = useListTransactions({ limit: 50 });

  const handleDownloadPdf = async () => {
    if (!reportRef.current) return;
    
    const canvas = await html2canvas(reportRef.current, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');
    const pdf = new jsPDF('p', 'mm', 'a4');
    
    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
    pdf.save('fintrack-report.pdf');
  };

  const isLoading = isLoadingSummary || isLoadingBreakdown || isLoadingTx;

  return (
    <div className="p-8 max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Reports</h1>
          <p className="text-muted-foreground">Generate and download financial reports.</p>
        </div>
        <Button onClick={handleDownloadPdf} disabled={isLoading}>
          <FileDown className="mr-2" size={16} /> Download PDF
        </Button>
      </div>

      <Card>
        <CardContent className="p-8" ref={reportRef}>
          {isLoading ? (
            <div className="space-y-4">
              <Skeleton className="h-8 w-1/3" />
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-64 w-full" />
            </div>
          ) : (
            <div className="space-y-8 bg-white text-black p-4 rounded-lg">
              <div className="text-center border-b pb-6">
                <h2 className="text-2xl font-bold">FinTrack Monthly Report</h2>
                <p className="text-gray-500">Generated on {formatDate(new Date().toISOString())}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-500">Total Income</p>
                  <p className="text-xl font-bold text-emerald-600">{formatCurrency(summary?.totalIncome || 0)}</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-500">Total Expenses</p>
                  <p className="text-xl font-bold text-rose-600">{formatCurrency(summary?.totalExpenses || 0)}</p>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-4 border-b pb-2">Category Breakdown</h3>
                <div className="space-y-2">
                  {breakdown?.map(b => (
                    <div key={b.categoryName} className="flex justify-between">
                      <span className="flex items-center gap-2">
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: b.categoryColor }}></span>
                        {b.categoryName}
                      </span>
                      <span className="font-medium">{formatCurrency(b.total)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-4 border-b pb-2">Recent Transactions</h3>
                <div className="space-y-2">
                  {txData?.transactions.slice(0, 15).map(tx => (
                    <div key={tx.id} className="flex justify-between text-sm py-1 border-b border-gray-100">
                      <span>{formatDate(tx.date)} - {tx.source || tx.categoryName}</span>
                      <span className={tx.type === 'income' ? 'text-emerald-600' : 'text-rose-600'}>
                        {tx.type === 'income' ? '+' : '-'}{formatCurrency(tx.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}