import React, { useState } from "react";
import { useListSavingsGoals, useDeleteSavingsGoal, useCreateSavingsGoal, getListSavingsGoalsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/format";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Trash2, Target } from "lucide-react";
import { toast } from "sonner";
import { useForm } from "react-hook-form";
import { Form, FormField, FormItem, FormControl, FormMessage } from "@/components/ui/form";

export default function SavingsGoals() {
  const { data: goals, isLoading } = useListSavingsGoals();
  const deleteGoal = useDeleteSavingsGoal();
  const createGoal = useCreateSavingsGoal();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);

  const form = useForm({
    defaultValues: {
      name: "",
      targetAmount: "",
      month: new Date().getMonth() + 1,
      year: new Date().getFullYear(),
      notes: ""
    }
  });

  const handleDelete = (id: number) => {
    deleteGoal.mutate(
      { id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSavingsGoalsQueryKey() });
          toast.success("Goal deleted");
        },
      }
    );
  };

  const onSubmit = (data: any) => {
    createGoal.mutate(
      { 
        data: {
          ...data,
          targetAmount: Number(data.targetAmount),
          month: Number(data.month),
          year: Number(data.year)
        }
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListSavingsGoalsQueryKey() });
          toast.success("Goal created");
          setOpen(false);
          form.reset();
        },
      }
    );
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground mb-2">Savings Goals</h1>
          <p className="text-muted-foreground">Track your progress.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2" size={16} /> Add Goal
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Savings Goal</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <Label>Goal Name</Label>
                      <FormControl>
                        <Input required placeholder="e.g. Emergency Fund" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="targetAmount"
                  render={({ field }) => (
                    <FormItem>
                      <Label>Target Amount</Label>
                      <FormControl>
                        <Input type="number" step="0.01" required {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="month"
                    render={({ field }) => (
                      <FormItem>
                        <Label>Month (1-12)</Label>
                        <FormControl>
                          <Input type="number" min="1" max="12" required {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="year"
                    render={({ field }) => (
                      <FormItem>
                        <Label>Year</Label>
                        <FormControl>
                          <Input type="number" min="2000" required {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <Label>Notes (Optional)</Label>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" className="w-full" disabled={createGoal.isPending}>
                  {createGoal.isPending ? "Creating..." : "Create Goal"}
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {isLoading ? (
          <>
            <Skeleton className="h-40 rounded-xl" />
            <Skeleton className="h-40 rounded-xl" />
          </>
        ) : goals && goals.length > 0 ? (
          goals.map((goal) => (
            <Card key={goal.id}>
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center text-primary shrink-0">
                      <Target size={20} />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg text-foreground">{goal.name}</h3>
                      <p className="text-sm text-muted-foreground">Target for {goal.month}/{goal.year}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon" onClick={() => handleDelete(goal.id)}>
                    <Trash2 className="text-destructive" size={16} />
                  </Button>
                </div>
                <div className="space-y-2 pt-2 border-t border-border">
                  <div className="flex justify-between items-center text-sm">
                    <span className="text-muted-foreground font-medium">Target Amount</span>
                    <span className="font-semibold text-lg text-primary">{formatCurrency(goal.targetAmount)}</span>
                  </div>
                  {goal.notes && <p className="text-sm text-muted-foreground italic bg-secondary p-2 rounded-md">{goal.notes}</p>}
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <div className="col-span-full p-12 text-center text-muted-foreground border border-dashed rounded-xl">
            No savings goals found.
          </div>
        )}
      </div>
    </div>
  );
}