import React from "react";
import { ProtectedLayout } from "@/components/layout";
import { Switch, Route, Redirect } from "wouter";
import Dashboard from "@/pages/dashboard";
import Transactions from "@/pages/transactions";
import Categories from "@/pages/categories";
import SavingsGoals from "@/pages/savings-goals";
import Profile from "@/pages/profile";
import Reports from "@/pages/reports";
import RecurringTransactions from "@/pages/recurring-transactions";

export function AppRoutes() {
  return (
    <Switch>
      <Route path="/dashboard"><ProtectedLayout><Dashboard /></ProtectedLayout></Route>
      <Route path="/transactions"><ProtectedLayout><Transactions /></ProtectedLayout></Route>
      <Route path="/recurring"><ProtectedLayout><RecurringTransactions /></ProtectedLayout></Route>
      <Route path="/categories"><ProtectedLayout><Categories /></ProtectedLayout></Route>
      <Route path="/savings-goals"><ProtectedLayout><SavingsGoals /></ProtectedLayout></Route>
      <Route path="/reports"><ProtectedLayout><Reports /></ProtectedLayout></Route>
      <Route path="/profile"><ProtectedLayout><Profile /></ProtectedLayout></Route>
      <Route><Redirect to="/dashboard" /></Route>
    </Switch>
  );
}