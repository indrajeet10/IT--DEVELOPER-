import { pgTable, text, serial, timestamp, doublePrecision, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const recurringTransactionsTable = pgTable("recurring_transactions", {
  id: serial("id").primaryKey(),
  clerkUserId: text("clerk_user_id").notNull(),
  type: text("type").notNull(), // income | expense
  amount: doublePrecision("amount").notNull(),
  categoryId: integer("category_id"),
  source: text("source"),
  paymentMethod: text("payment_method"),
  notes: text("notes"),
  frequency: text("frequency").notNull(), // daily | weekly | monthly | yearly
  startDate: text("start_date").notNull(), // YYYY-MM-DD
  endDate: text("end_date"), // YYYY-MM-DD nullable
  nextDate: text("next_date").notNull(), // YYYY-MM-DD - date of next occurrence
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertRecurringTransactionSchema = createInsertSchema(recurringTransactionsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});
export type InsertRecurringTransaction = z.infer<typeof insertRecurringTransactionSchema>;
export type RecurringTransaction = typeof recurringTransactionsTable.$inferSelect;
