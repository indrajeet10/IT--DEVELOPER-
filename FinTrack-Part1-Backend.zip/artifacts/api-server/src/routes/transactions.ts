import { Router, type IRouter } from "express";
import { eq, and, gte, lte, sql } from "drizzle-orm";
import { db, transactionsTable, categoriesTable } from "@workspace/db";
import {
  CreateTransactionBody,
  UpdateTransactionBody,
  UpdateTransactionParams,
  DeleteTransactionParams,
  GetTransactionParams,
  ListTransactionsQueryParams,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";

const router: IRouter = Router();

router.get("/transactions", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const query = ListTransactionsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const { type, categoryId, startDate, endDate, limit = 100, offset = 0 } = query.data;

  const conditions = [eq(transactionsTable.clerkUserId, userId)];
  if (type) conditions.push(eq(transactionsTable.type, type));
  if (categoryId) conditions.push(eq(transactionsTable.categoryId, categoryId));
  if (startDate) conditions.push(gte(transactionsTable.date, startDate));
  if (endDate) conditions.push(lte(transactionsTable.date, endDate));

  const [countResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(transactionsTable)
    .where(and(...conditions));

  const rows = await db
    .select({
      id: transactionsTable.id,
      clerkUserId: transactionsTable.clerkUserId,
      type: transactionsTable.type,
      amount: transactionsTable.amount,
      categoryId: transactionsTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      source: transactionsTable.source,
      paymentMethod: transactionsTable.paymentMethod,
      date: transactionsTable.date,
      notes: transactionsTable.notes,
      createdAt: transactionsTable.createdAt,
      updatedAt: transactionsTable.updatedAt,
    })
    .from(transactionsTable)
    .leftJoin(categoriesTable, eq(transactionsTable.categoryId, categoriesTable.id))
    .where(and(...conditions))
    .orderBy(sql`${transactionsTable.date} desc, ${transactionsTable.createdAt} desc`)
    .limit(limit)
    .offset(offset);

  res.json({ transactions: rows, total: countResult?.count ?? 0 });
});

router.post("/transactions", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const parsed = CreateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [tx] = await db
    .insert(transactionsTable)
    .values({
      clerkUserId: userId,
      type: parsed.data.type,
      amount: parsed.data.amount,
      categoryId: parsed.data.categoryId ?? null,
      source: parsed.data.source ?? null,
      paymentMethod: parsed.data.paymentMethod ?? null,
      date: parsed.data.date,
      notes: parsed.data.notes ?? null,
    })
    .returning();

  // Fetch with category info
  const [withCategory] = await db
    .select({
      id: transactionsTable.id,
      clerkUserId: transactionsTable.clerkUserId,
      type: transactionsTable.type,
      amount: transactionsTable.amount,
      categoryId: transactionsTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      source: transactionsTable.source,
      paymentMethod: transactionsTable.paymentMethod,
      date: transactionsTable.date,
      notes: transactionsTable.notes,
      createdAt: transactionsTable.createdAt,
      updatedAt: transactionsTable.updatedAt,
    })
    .from(transactionsTable)
    .leftJoin(categoriesTable, eq(transactionsTable.categoryId, categoriesTable.id))
    .where(eq(transactionsTable.id, tx.id));

  res.status(201).json(withCategory);
});

router.get("/transactions/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const params = GetTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [tx] = await db
    .select({
      id: transactionsTable.id,
      clerkUserId: transactionsTable.clerkUserId,
      type: transactionsTable.type,
      amount: transactionsTable.amount,
      categoryId: transactionsTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      source: transactionsTable.source,
      paymentMethod: transactionsTable.paymentMethod,
      date: transactionsTable.date,
      notes: transactionsTable.notes,
      createdAt: transactionsTable.createdAt,
      updatedAt: transactionsTable.updatedAt,
    })
    .from(transactionsTable)
    .leftJoin(categoriesTable, eq(transactionsTable.categoryId, categoriesTable.id))
    .where(and(eq(transactionsTable.id, params.data.id), eq(transactionsTable.clerkUserId, userId)));

  if (!tx) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }

  res.json(tx);
});

router.patch("/transactions/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const params = UpdateTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updates: Record<string, unknown> = {};
  if (parsed.data.type !== undefined) updates.type = parsed.data.type;
  if (parsed.data.amount !== undefined) updates.amount = parsed.data.amount;
  if (parsed.data.categoryId !== undefined) updates.categoryId = parsed.data.categoryId;
  if (parsed.data.source !== undefined) updates.source = parsed.data.source;
  if (parsed.data.paymentMethod !== undefined) updates.paymentMethod = parsed.data.paymentMethod;
  if (parsed.data.date !== undefined) updates.date = parsed.data.date;
  if (parsed.data.notes !== undefined) updates.notes = parsed.data.notes;

  const [updated] = await db
    .update(transactionsTable)
    .set(updates)
    .where(and(eq(transactionsTable.id, params.data.id), eq(transactionsTable.clerkUserId, userId)))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }

  const [withCategory] = await db
    .select({
      id: transactionsTable.id,
      clerkUserId: transactionsTable.clerkUserId,
      type: transactionsTable.type,
      amount: transactionsTable.amount,
      categoryId: transactionsTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      source: transactionsTable.source,
      paymentMethod: transactionsTable.paymentMethod,
      date: transactionsTable.date,
      notes: transactionsTable.notes,
      createdAt: transactionsTable.createdAt,
      updatedAt: transactionsTable.updatedAt,
    })
    .from(transactionsTable)
    .leftJoin(categoriesTable, eq(transactionsTable.categoryId, categoriesTable.id))
    .where(eq(transactionsTable.id, updated.id));

  res.json(withCategory);
});

router.delete("/transactions/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const params = DeleteTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(transactionsTable)
    .where(and(eq(transactionsTable.id, params.data.id), eq(transactionsTable.clerkUserId, userId)))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Transaction not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
