import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import categoriesRouter from "./categories";
import transactionsRouter from "./transactions";
import savingsGoalsRouter from "./savings-goals";
import dashboardRouter from "./dashboard";
import recurringTransactionsRouter from "./recurring-transactions";

const router: IRouter = Router();

router.use(healthRouter);
router.use(usersRouter);
router.use(categoriesRouter);
router.use(transactionsRouter);
router.use(savingsGoalsRouter);
router.use(dashboardRouter);
router.use(recurringTransactionsRouter);

export default router;
