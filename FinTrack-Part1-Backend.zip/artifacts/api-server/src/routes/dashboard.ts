import { Router, type IRouter } from "express";
import { eq, and, gte, lte, sql } from "drizzle-orm";
import { db, transactionsTable, categoriesTable, savingsGoalsTable, usersTable } from "@workspace/db";
import {
  GetDashboardSummaryQueryParams,
  GetCategoryBreakdownQueryParams,
  GetMonthlyTrendQueryParams,
  GetRecentTransactionsQueryParams,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";

const router: IRouter = Router();

router.get("/dashboard/summary", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const query = GetDashboardSummaryQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const now = new Date();
  const month = query.data.month ?? now.getMonth() + 1;
  const year = query.data.year ?? now.getFullYear();

  const monthStr = String(month).padStart(2, "0");
  const startDate = `${year}-${monthStr}-01`;
  const lastDay = new Date(year, month, 0).getDate();
  const endDate = `${year}-${monthStr}-${String(lastDay).padStart(2, "0")}`;

  const conditions = [
    eq(transactionsTable.clerkUserId, userId),
    gte(transactionsTable.date, startDate),
    lte(transactionsTable.date, endDate),
  ];

  // Income total
  const [incomeResult] = await db
    .select({ total: sql<number>`coalesce(sum(amount), 0)::float` })
    .from(transactionsTable)
    .where(and(...conditions, eq(transactionsTable.type, "income")));

  // Expense total
  const [expenseResult] = await db
    .select({ total: sql<number>`coalesce(sum(amount), 0)::float` })
    .from(transactionsTable)
    .where(and(...conditions, eq(transactionsTable.type, "expense")));

  const totalIncome = incomeResult?.total ?? 0;
  const totalExpenses = expenseResult?.total ?? 0;
  const netSavings = totalIncome - totalExpenses;

  // Transaction count
  const [countResult] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(transactionsTable)
    .where(and(...conditions));

  // Biggest expense category
  const categoryTotals = await db
    .select({
      name: categoriesTable.name,
      total: sql<number>`coalesce(sum(${transactionsTable.amount}), 0)::float`,
    })
    .from(transactionsTable)
    .leftJoin(categoriesTable, eq(transactionsTable.categoryId, categoriesTable.id))
    .where(and(...conditions, eq(transactionsTable.type, "expense")))
    .groupBy(categoriesTable.name)
    .orderBy(sql`sum(${transactionsTable.amount}) desc`)
    .limit(1);

  // Savings goal for this month/year
  const [goal] = await db
    .select()
    .from(savingsGoalsTable)
    .where(
      and(
        eq(savingsGoalsTable.clerkUserId, userId),
        eq(savingsGoalsTable.month, month),
        eq(savingsGoalsTable.year, year)
      )
    );

  // Also check user's monthly savings goal
  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkUserId, userId));
  const savingsGoalTarget = goal?.targetAmount ?? user?.monthlySavingsGoal ?? null;
  const savingsGoalProgress = savingsGoalTarget ? Math.min((netSavings / savingsGoalTarget) * 100, 100) : null;

  res.json({
    totalIncome,
    totalExpenses,
    netSavings,
    savingsGoalTarget,
    savingsGoalProgress,
    biggestExpenseCategory: categoryTotals[0]?.name ?? null,
    biggestExpenseCategoryAmount: categoryTotals[0]?.total ?? null,
    transactionCount: countResult?.count ?? 0,
  });
});

router.get("/dashboard/category-breakdown", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const query = GetCategoryBreakdownQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const conditions = [eq(transactionsTable.clerkUserId, userId), eq(transactionsTable.type, "expense")];
  if (query.data.startDate) conditions.push(gte(transactionsTable.date, query.data.startDate));
  if (query.data.endDate) conditions.push(lte(transactionsTable.date, query.data.endDate));

  const [totalResult] = await db
    .select({ total: sql<number>`coalesce(sum(amount), 0)::float` })
    .from(transactionsTable)
    .where(and(...conditions));

  const grandTotal = totalResult?.total ?? 0;

  const rows = await db
    .select({
      categoryId: transactionsTable.categoryId,
      categoryName: sql<string>`coalesce(${categoriesTable.name}, 'Uncategorized')`,
      categoryColor: sql<string>`coalesce(${categoriesTable.color}, '#94a3b8')`,
      total: sql<number>`coalesce(sum(${transactionsTable.amount}), 0)::float`,
      count: sql<number>`count(*)::int`,
    })
    .from(transactionsTable)
    .leftJoin(categoriesTable, eq(transactionsTable.categoryId, categoriesTable.id))
    .where(and(...conditions))
    .groupBy(transactionsTable.categoryId, categoriesTable.name, categoriesTable.color)
    .orderBy(sql`sum(${transactionsTable.amount}) desc`);

  const result = rows.map((row) => ({
    ...row,
    percentage: grandTotal > 0 ? Math.round((row.total / grandTotal) * 10000) / 100 : 0,
  }));

  res.json(result);
});

router.get("/dashboard/monthly-trend", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const query = GetMonthlyTrendQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const months = query.data.months ?? 6;
  const now = new Date();
  const result = [];

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  for (let i = months - 1; i >= 0; i--) {
    const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const m = d.getMonth() + 1;
    const y = d.getFullYear();
    const monthStr = String(m).padStart(2, "0");
    const start = `${y}-${monthStr}-01`;
    const lastDay = new Date(y, m, 0).getDate();
    const end = `${y}-${monthStr}-${String(lastDay).padStart(2, "0")}`;

    const conds = [eq(transactionsTable.clerkUserId, userId), gte(transactionsTable.date, start), lte(transactionsTable.date, end)];

    const [inc] = await db
      .select({ total: sql<number>`coalesce(sum(amount), 0)::float` })
      .from(transactionsTable)
      .where(and(...conds, eq(transactionsTable.type, "income")));

    const [exp] = await db
      .select({ total: sql<number>`coalesce(sum(amount), 0)::float` })
      .from(transactionsTable)
      .where(and(...conds, eq(transactionsTable.type, "expense")));

    const income = inc?.total ?? 0;
    const expenses = exp?.total ?? 0;

    result.push({
      month: m,
      year: y,
      label: `${monthNames[m - 1]} ${y}`,
      income,
      expenses,
      savings: income - expenses,
    });
  }

  res.json(result);
});

router.get("/dashboard/recent-transactions", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const query = GetRecentTransactionsQueryParams.safeParse(req.query);
  if (!query.success) {
    res.status(400).json({ error: query.error.message });
    return;
  }

  const limit = query.data.limit ?? 10;

  const rows = await db
    .select({
      id: transactionsTable.id,
      clerkUserId: transactionsTable.clerkUserId,
      type: transactionsTable.type,
      amount: transactionsTable.amount,
      categoryId: transactionsTable.categoryId,
      categoryName: categoriesTable.name,
      categoryColor: categoriesTable.color,
      source: transactionsTable.source,
      paymentMethod: transactionsTable.paymentMethod,
      date: transactionsTable.date,
      notes: transactionsTable.notes,
      createdAt: transactionsTable.createdAt,
      updatedAt: transactionsTable.updatedAt,
    })
    .from(transactionsTable)
    .leftJoin(categoriesTable, eq(transactionsTable.categoryId, categoriesTable.id))
    .where(eq(transactionsTable.clerkUserId, userId))
    .orderBy(sql`${transactionsTable.date} desc, ${transactionsTable.createdAt} desc`)
    .limit(limit);

  res.json(rows);
});

export default router;
