import { Router, type IRouter } from "express";
import { eq, and, lte } from "drizzle-orm";
import { db, recurringTransactionsTable, transactionsTable, categoriesTable } from "@workspace/db";
import {
  CreateRecurringTransactionBody,
  UpdateRecurringTransactionBody,
  UpdateRecurringTransactionParams,
  DeleteRecurringTransactionParams,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";

const router: IRouter = Router();

function advanceDate(date: string, frequency: string): string {
  const d = new Date(date);
  switch (frequency) {
    case "daily":
      d.setUTCDate(d.getUTCDate() + 1);
      break;
    case "weekly":
      d.setUTCDate(d.getUTCDate() + 7);
      break;
    case "monthly":
      d.setUTCMonth(d.getUTCMonth() + 1);
      break;
    case "yearly":
      d.setUTCFullYear(d.getUTCFullYear() + 1);
      break;
  }
  return d.toISOString().slice(0, 10);
}

router.get("/recurring-transactions", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const rows = await db
    .select()
    .from(recurringTransactionsTable)
    .where(eq(recurringTransactionsTable.clerkUserId, userId))
    .orderBy(recurringTransactionsTable.createdAt);

  res.json({ recurringTransactions: rows });
});

router.post("/recurring-transactions/apply", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const today = new Date().toISOString().slice(0, 10);

  const due = await db
    .select()
    .from(recurringTransactionsTable)
    .where(
      and(
        eq(recurringTransactionsTable.clerkUserId, userId),
        eq(recurringTransactionsTable.isActive, true),
        lte(recurringTransactionsTable.nextDate, today),
      ),
    );

  let applied = 0;

  for (const rt of due) {
    let current = rt.nextDate;

    while (current <= today) {
      if (rt.endDate && current > rt.endDate) break;

      await db.insert(transactionsTable).values({
        clerkUserId: userId,
        type: rt.type,
        amount: rt.amount,
        categoryId: rt.categoryId ?? null,
        source: rt.source ?? null,
        paymentMethod: rt.paymentMethod ?? null,
        date: current,
        notes: rt.notes ?? null,
      });
      applied++;

      const next = advanceDate(current, rt.frequency);
      current = next;
    }

    const shouldPause = rt.endDate && current > rt.endDate;
    await db
      .update(recurringTransactionsTable)
      .set({ nextDate: current, isActive: shouldPause ? false : rt.isActive })
      .where(eq(recurringTransactionsTable.id, rt.id));
  }

  res.json({ applied });
});

router.post("/recurring-transactions", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const parsed = CreateRecurringTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { type, amount, categoryId, source, paymentMethod, notes, frequency, startDate, endDate, nextDate, isActive } =
    parsed.data;

  const [rt] = await db
    .insert(recurringTransactionsTable)
    .values({
      clerkUserId: userId,
      type,
      amount,
      categoryId: categoryId ?? null,
      source: source ?? null,
      paymentMethod: paymentMethod ?? null,
      notes: notes ?? null,
      frequency,
      startDate,
      endDate: endDate ?? null,
      nextDate: nextDate ?? startDate,
      isActive: isActive ?? true,
    })
    .returning();

  res.status(201).json(rt);
});

router.patch("/recurring-transactions/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const params = UpdateRecurringTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateRecurringTransactionBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updates: Record<string, unknown> = {};
  const d = parsed.data;
  if (d.type !== undefined) updates.type = d.type;
  if (d.amount !== undefined) updates.amount = d.amount;
  if (d.categoryId !== undefined) updates.categoryId = d.categoryId;
  if (d.source !== undefined) updates.source = d.source;
  if (d.paymentMethod !== undefined) updates.paymentMethod = d.paymentMethod;
  if (d.notes !== undefined) updates.notes = d.notes;
  if (d.frequency !== undefined) updates.frequency = d.frequency;
  if (d.startDate !== undefined) updates.startDate = d.startDate;
  if (d.endDate !== undefined) updates.endDate = d.endDate;
  if (d.nextDate !== undefined) updates.nextDate = d.nextDate;
  if (d.isActive !== undefined) updates.isActive = d.isActive;

  const [updated] = await db
    .update(recurringTransactionsTable)
    .set(updates)
    .where(and(eq(recurringTransactionsTable.id, params.data.id), eq(recurringTransactionsTable.clerkUserId, userId)))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Recurring transaction not found" });
    return;
  }

  res.json(updated);
});

router.delete("/recurring-transactions/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const params = DeleteRecurringTransactionParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(recurringTransactionsTable)
    .where(and(eq(recurringTransactionsTable.id, params.data.id), eq(recurringTransactionsTable.clerkUserId, userId)))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Recurring transaction not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
