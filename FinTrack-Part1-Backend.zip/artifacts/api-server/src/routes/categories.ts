import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, categoriesTable } from "@workspace/db";
import { CreateCategoryBody, UpdateCategoryBody, UpdateCategoryParams, DeleteCategoryParams } from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";

const router: IRouter = Router();

// Default categories seeded per user on first access
const DEFAULT_CATEGORIES = [
  { name: "Food & Dining", type: "expense", color: "#ef4444", icon: "utensils" },
  { name: "Rent & Housing", type: "expense", color: "#f97316", icon: "home" },
  { name: "Utilities", type: "expense", color: "#eab308", icon: "zap" },
  { name: "Travel & Transport", type: "expense", color: "#06b6d4", icon: "car" },
  { name: "Shopping", type: "expense", color: "#8b5cf6", icon: "shopping-bag" },
  { name: "Healthcare", type: "expense", color: "#ec4899", icon: "heart-pulse" },
  { name: "Entertainment", type: "expense", color: "#14b8a6", icon: "film" },
  { name: "Education", type: "expense", color: "#3b82f6", icon: "book" },
  { name: "Salary", type: "income", color: "#22c55e", icon: "briefcase" },
  { name: "Freelance", type: "income", color: "#10b981", icon: "laptop" },
  { name: "Investment", type: "income", color: "#84cc16", icon: "trending-up" },
  { name: "Other Income", type: "income", color: "#6ee7b7", icon: "plus-circle" },
];

router.get("/categories", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;

  // Seed defaults if none exist
  const existing = await db.select().from(categoriesTable).where(eq(categoriesTable.clerkUserId, userId));
  if (existing.length === 0) {
    await db.insert(categoriesTable).values(
      DEFAULT_CATEGORIES.map((c) => ({
        clerkUserId: userId,
        name: c.name,
        type: c.type,
        color: c.color,
        icon: c.icon,
        isDefault: true,
      }))
    );
    const seeded = await db.select().from(categoriesTable).where(eq(categoriesTable.clerkUserId, userId));
    res.json(seeded);
    return;
  }

  res.json(existing);
});

router.post("/categories", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const parsed = CreateCategoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [category] = await db
    .insert(categoriesTable)
    .values({
      clerkUserId: userId,
      name: parsed.data.name,
      type: parsed.data.type,
      color: parsed.data.color,
      icon: parsed.data.icon ?? null,
      isDefault: false,
    })
    .returning();

  res.status(201).json(category);
});

router.patch("/categories/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const params = UpdateCategoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateCategoryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [category] = await db
    .update(categoriesTable)
    .set({
      ...(parsed.data.name !== undefined && { name: parsed.data.name }),
      ...(parsed.data.type !== undefined && { type: parsed.data.type }),
      ...(parsed.data.color !== undefined && { color: parsed.data.color }),
      ...(parsed.data.icon !== undefined && { icon: parsed.data.icon }),
    })
    .where(and(eq(categoriesTable.id, params.data.id), eq(categoriesTable.clerkUserId, userId)))
    .returning();

  if (!category) {
    res.status(404).json({ error: "Category not found" });
    return;
  }

  res.json(category);
});

router.delete("/categories/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const params = DeleteCategoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(categoriesTable)
    .where(and(eq(categoriesTable.id, params.data.id), eq(categoriesTable.clerkUserId, userId)))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Category not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
