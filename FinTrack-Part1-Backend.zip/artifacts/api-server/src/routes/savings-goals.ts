import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import { db, savingsGoalsTable } from "@workspace/db";
import {
  CreateSavingsGoalBody,
  UpdateSavingsGoalBody,
  UpdateSavingsGoalParams,
  DeleteSavingsGoalParams,
} from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";

const router: IRouter = Router();

router.get("/savings-goals", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const goals = await db
    .select()
    .from(savingsGoalsTable)
    .where(eq(savingsGoalsTable.clerkUserId, userId))
    .orderBy(savingsGoalsTable.year, savingsGoalsTable.month);
  res.json(goals);
});

router.post("/savings-goals", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const parsed = CreateSavingsGoalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [goal] = await db
    .insert(savingsGoalsTable)
    .values({
      clerkUserId: userId,
      name: parsed.data.name,
      targetAmount: parsed.data.targetAmount,
      month: parsed.data.month,
      year: parsed.data.year,
      notes: parsed.data.notes ?? null,
    })
    .returning();

  res.status(201).json(goal);
});

router.patch("/savings-goals/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const params = UpdateSavingsGoalParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateSavingsGoalBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const updates: Record<string, unknown> = {};
  if (parsed.data.name !== undefined) updates.name = parsed.data.name;
  if (parsed.data.targetAmount !== undefined) updates.targetAmount = parsed.data.targetAmount;
  if (parsed.data.month !== undefined) updates.month = parsed.data.month;
  if (parsed.data.year !== undefined) updates.year = parsed.data.year;
  if (parsed.data.notes !== undefined) updates.notes = parsed.data.notes;

  const [goal] = await db
    .update(savingsGoalsTable)
    .set(updates)
    .where(and(eq(savingsGoalsTable.id, params.data.id), eq(savingsGoalsTable.clerkUserId, userId)))
    .returning();

  if (!goal) {
    res.status(404).json({ error: "Savings goal not found" });
    return;
  }

  res.json(goal);
});

router.delete("/savings-goals/:id", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const params = DeleteSavingsGoalParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(savingsGoalsTable)
    .where(and(eq(savingsGoalsTable.id, params.data.id), eq(savingsGoalsTable.clerkUserId, userId)))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Savings goal not found" });
    return;
  }

  res.sendStatus(204);
});

export default router;
