import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import { UpsertUserProfileBody } from "@workspace/api-zod";
import { requireAuth, type AuthRequest } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";

const router: IRouter = Router();

router.get("/users/profile", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.clerkUserId, userId));
  if (!user) {
    res.status(404).json({ error: "User profile not found" });
    return;
  }
  res.json(user);
});

router.put("/users/profile", requireAuth, async (req, res): Promise<void> => {
  const userId = (req as AuthRequest).userId;
  const parsed = UpsertUserProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const data = parsed.data;
  const [existing] = await db.select().from(usersTable).where(eq(usersTable.clerkUserId, userId));

  if (existing) {
    const [updated] = await db
      .update(usersTable)
      .set({
        ...(data.name !== undefined && { name: data.name }),
        ...(data.email !== undefined && { email: data.email }),
        ...(data.currency !== undefined && { currency: data.currency }),
        ...(data.monthlySavingsGoal !== undefined && { monthlySavingsGoal: data.monthlySavingsGoal }),
      })
      .where(eq(usersTable.clerkUserId, userId))
      .returning();
    res.json(updated);
  } else {
    const [created] = await db
      .insert(usersTable)
      .values({
        clerkUserId: userId,
        name: data.name ?? "User",
        email: data.email ?? "",
        currency: data.currency ?? "USD",
        monthlySavingsGoal: data.monthlySavingsGoal ?? null,
      })
      .returning();
    res.json(created);
  }
});

export default router;
